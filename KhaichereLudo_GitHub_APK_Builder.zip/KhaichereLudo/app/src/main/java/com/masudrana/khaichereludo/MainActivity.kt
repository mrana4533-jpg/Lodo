package com.masudrana.khaichereludo

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Canvas
import android.graphics.RectF
import android.view.View
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.random.Random

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var board: LudoBoardView
    private lateinit var status: TextView
    private lateinit var diceText: TextView
    private var dice = 0
    private var currentPlayer = 0
    private val names = arrayOf("লাল", "সবুজ", "হলুদ", "নীল")
    private val colors = intArrayOf(Color.rgb(220, 45, 55), Color.rgb(36, 160, 85),
        Color.rgb(245, 190, 35), Color.rgb(45, 105, 220))
    private val positions = IntArray(4) { -1 }
    private val playerWins = BooleanArray(4)
    private var extraTurn = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(12, 12, 12, 12)
            setBackgroundColor(Color.rgb(248, 246, 239))
        }
        val title = TextView(this).apply {
            text = "🎲 খাইছেরে লুডু"
            textSize = 27f
            setTextColor(Color.rgb(34, 47, 62))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 8)
        }
        status = TextView(this).apply {
            text = "লাল খেলোয়াড়ের পালা। পাশা ফেলো!"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(4, 8, 4, 8)
        }
        board = LudoBoardView(this, colors, positions) { token ->
            onTokenTapped(token)
        }
        diceText = TextView(this).apply {
            text = "🎲 পাশা: —"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
            setPadding(0, 8, 0, 8)
        }
        val roll = Button(this).apply {
            text = "পাশা ফেলো"
            textSize = 18f
            setOnClickListener { rollDice() }
        }
        val reset = Button(this).apply {
            text = "নতুন খেলা"
            setOnClickListener { resetGame() }
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(roll, LinearLayout.LayoutParams(0, -2, 1f))
            addView(reset, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(board, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(diceText, LinearLayout.LayoutParams(-1, -2))
        root.addView(buttons, LinearLayout.LayoutParams(-1, -2))
        val note = TextView(this).apply {
            text = "গুটি বের করতে ৬ লাগবে। গুটি কাটলে ‘খাইছেরে!’"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 6, 0, 0)
        }
        root.addView(note, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("bn", "BD"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
            if (!ttsReady) {
                runOnUiThread {
                    Toast.makeText(this, "বাংলা TTS নেই। ফোনের Text-to-Speech সেটিংসে বাংলা ভয়েস ইনস্টল করুন।", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ludo_voice")
        else Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private fun rollDice() {
        dice = Random.nextInt(1, 7)
        diceText.text = "🎲 পাশা: $dice"
        if (dice == 6) speak("ছয়!")
        else if (dice == 1) speak("কানা পড়ছে রে!")
        extraTurn = dice == 6
        status.text = "${names[currentPlayer]} খেলোয়াড়ের চাল — পাশায় $dice উঠেছে। গুটিতে চাপ দাও।"
        board.invalidate()
    }

    private fun onTokenTapped(token: Int) {
        if (dice == 0) {
            Toast.makeText(this, "আগে পাশা ফেলো!", Toast.LENGTH_SHORT).show()
            return
        }
        if (token != currentPlayer) {
            Toast.makeText(this, "এখন ${names[currentPlayer]} খেলোয়াড়ের পালা।", Toast.LENGTH_SHORT).show()
            return
        }
        if (positions[token] == -1 && dice != 6) {
            Toast.makeText(this, "গুটি বের করতে ৬ লাগবে!", Toast.LENGTH_SHORT).show()
            return
        }
        positions[token] = if (positions[token] < 0) 0 else (positions[token] + dice).coerceAtMost(56)
        var captured = false
        // Simple playable demo rule: a token landing on another active token's shared track position captures it.
        for (i in positions.indices) {
            if (i != token && positions[i] >= 0 && positions[i] < 56 &&
                positions[i] == positions[token] && positions[token] > 0) {
                positions[i] = -1
                captured = true
            }
        }
        if (captured) speak("খাইছেরে!")
        if (positions[token] >= 56) {
            playerWins[token] = true
            speak("${names[token]} জিতে গেছে!")
            status.text = "🎉 ${names[token]} খেলোয়াড় জিতে গেছে!"
            dice = 0
            board.invalidate()
            return
        }
        if (extraTurn) {
            status.text = "${names[currentPlayer]} আবার চাল পাবে! গুটি বেছে নাও।"
        } else {
            currentPlayer = (currentPlayer + 1) % 4
            status.text = "এখন ${names[currentPlayer]} খেলোয়াড়ের পালা। পাশা ফেলো!"
        }
        dice = 0
        diceText.text = "🎲 পাশা: —"
        board.invalidate()
    }

    private fun resetGame() {
        for (i in positions.indices) positions[i] = -1
        for (i in playerWins.indices) playerWins[i] = false
        currentPlayer = 0
        dice = 0
        extraTurn = false
        diceText.text = "🎲 পাশা: —"
        status.text = "নতুন খেলা! লাল খেলোয়াড়ের পালা।"
        board.invalidate()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private class LudoBoardView(
    context: android.content.Context,
    private val tokenColors: IntArray,
    private val positions: IntArray,
    private val onToken: (Int) -> Unit
) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tokenRects = Array(4) { RectF() }
    private val track = ArrayList<Pair<Float, Float>>()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val side = minOf(width.toFloat(), height.toFloat())
        val left = (width - side) / 2f
        val top = (height - side) / 2f
        val cell = side / 15f
        canvas.drawColor(Color.rgb(248, 246, 239))

        // Four colored home zones.
        val zones = arrayOf(
            RectF(left, top, left + 6*cell, top + 6*cell),
            RectF(left, top + 9*cell, left + 6*cell, top + 15*cell),
            RectF(left + 9*cell, top + 9*cell, left + 15*cell, top + 15*cell),
            RectF(left + 9*cell, top, left + 15*cell, top + 6*cell)
        )
        val zoneColors = intArrayOf(tokenColors[0], tokenColors[1], tokenColors[2], tokenColors[3])
        for (i in zones.indices) {
            paint.color = zoneColors[i]
            canvas.drawRoundRect(zones[i], 10f, 10f, paint)
            paint.color = Color.WHITE
            val z = zones[i]
            canvas.drawRoundRect(RectF(z.left + cell*.7f, z.top + cell*.7f, z.right - cell*.7f, z.bottom - cell*.7f), 12f, 12f, paint)
        }

        // Draw central home.
        paint.color = Color.rgb(255, 250, 225)
        canvas.drawRect(left + 6*cell, top + 6*cell, left + 9*cell, top + 9*cell, paint)
        paint.color = tokenColors[0]
        canvas.drawRect(left + 6*cell, top + 6*cell, left + 7.5f*cell, top + 7.5f*cell, paint)
        paint.color = tokenColors[1]
        canvas.drawRect(left + 6*cell, top + 7.5f*cell, left + 7.5f*cell, top + 9*cell, paint)
        paint.color = tokenColors[2]
        canvas.drawRect(left + 7.5f*cell, top + 7.5f*cell, left + 9*cell, top + 9*cell, paint)
        paint.color = tokenColors[3]
        canvas.drawRect(left + 7.5f*cell, top + 6*cell, left + 9*cell, top + 7.5f*cell, paint)

        // Track tiles around the board (stylized Ludo path).
        track.clear()
        for (i in 1..6) track.add(Pair(left + (6+i*.0f)*cell, top + (6-i)*cell))
        val path = arrayListOf<Pair<Int,Int>>()
        for (x in 1..5) path.add(Pair(7, x))
        for (y in 1..5) path.add(Pair(7+y, 5))
        for (x in 1..5) path.add(Pair(12, 5+x))
        for (y in 1..5) path.add(Pair(12-y, 10))
        for (x in 1..5) path.add(Pair(7, 10+x))
        for (y in 1..5) path.add(Pair(7-y, 15-y))
        for (i in 0 until 52) {
            val p = path[i % path.size]
            paint.color = Color.rgb(224, 226, 222)
            canvas.drawRect(left+p.first*cell, top+p.second*cell, left+(p.first+1)*cell, top+(p.second+1)*cell, paint)
            paint.color = Color.rgb(180, 185, 180)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            canvas.drawRect(left+p.first*cell, top+p.second*cell, left+(p.first+1)*cell, top+(p.second+1)*cell, paint)
            paint.style = Paint.Style.FILL
        }

        // Home tokens; the position count is represented along the path for this compact demo.
        val starts = arrayOf(
            Pair(left + 2.2f*cell, top + 2.2f*cell),
            Pair(left + 2.2f*cell, top + 12.2f*cell),
            Pair(left + 12.2f*cell, top + 12.2f*cell),
            Pair(left + 12.2f*cell, top + 2.2f*cell)
        )
        val radius = cell * .31f
        for (i in 0..3) {
            val p = starts[i]
            val x: Float
            val y: Float
            if (positions[i] < 0) {
                x = p.first; y = p.second
            } else {
                val n = positions[i]
                val angle = (n % 52) * (2 * Math.PI / 52.0)
                val cx = left + side/2f
                val cy = top + side/2f
                val orbit = side * .31f
                x = cx + (kotlin.math.cos(angle) * orbit).toFloat()
                y = cy + (kotlin.math.sin(angle) * orbit).toFloat()
            }
            tokenRects[i].set(x-radius, y-radius, x+radius, y+radius)
            paint.color = Color.BLACK
            canvas.drawCircle(x, y, radius+3f, paint)
            paint.color = tokenColors[i]
            canvas.drawCircle(x, y, radius, paint)
            paint.color = Color.WHITE
            paint.textSize = radius
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("${i+1}", x, y+radius*.35f, paint)
        }

        paint.color = Color.rgb(45, 50, 55)
        paint.textSize = cell * .36f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("LUDO", width/2f, top + side/2f + cell*.12f, paint)
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action == android.view.MotionEvent.ACTION_UP) {
            for (i in tokenRects.indices) {
                if (tokenRects[i].contains(event.x, event.y)) {
                    onToken(i)
                    return true
                }
            }
        }
        return true
    }
}
